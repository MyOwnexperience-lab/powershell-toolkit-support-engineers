# Gebruiksaanwijzing

Plaats je scripts in de `scripts/` map. Elk script heeft duidelijke parameters en logging.  
Gebruik `.\scriptnaam.ps1 -Help` voor uitleg (waar ondersteund).

## Benodigdheden
- PowerShell 5.1 of PowerShell Core
- Microsoft Graph module (`Install-Module Microsoft.Graph`)
- Verbinding met Microsoft 365/Azure AD

## Let op
Gebruik deze scripts met beheerdersrechten en test altijd in een veilige omgeving.
