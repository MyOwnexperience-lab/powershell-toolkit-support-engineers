<#
.SYNOPSIS
Genereert een rapport van MFA-statussen van alle gebruikers.

.AUTHOR
Mounir Oss

.DESCRIPTION
Rapporteert welke gebruikers MFA aan/uit hebben, welke methodes zijn geconfigureerd,
en exporteert resultaten naar een CSV-bestand.

#>

Connect-MgGraph -Scopes "User.Read.All", "Policy.Read.All"

$users = Get-MgUser -All
$results = foreach ($user in $users) {
    $methods = Get-MgUserAuthenticationMethod -UserId $user.Id
    [PSCustomObject]@{
        UserPrincipalName = $user.UserPrincipalName
        MFAEnabled = if ($methods) { "Yes" } else { "No" }
        Methods = ($methods | Select-Object -ExpandProperty odataType -Unique) -join ", "
    }
}

$results | Export-Csv -Path "./MFA_Report.csv" -NoTypeInformation
Write-Host "MFA rapport opgeslagen als MFA_Report.csv"
