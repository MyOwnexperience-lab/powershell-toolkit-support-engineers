<#
.SYNOPSIS
Detecteert indirecte Global Admins via groepslidmaatschap.

.AUTHOR
Mounir Oss

.DESCRIPTION
Zoekt gebruikers met hoge rechten via groepstoewijzingen die niet direct zichtbaar zijn.
#>

Connect-AzureAD

$role = Get-AzureADDirectoryRole | Where-Object { $_.DisplayName -eq "Company Administrator" }
$members = Get-AzureADDirectoryRoleMember -ObjectId $role.ObjectId

$members | Select DisplayName, UserPrincipalName, ObjectType
