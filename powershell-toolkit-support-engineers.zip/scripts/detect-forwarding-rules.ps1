<#
.SYNOPSIS
Detecteert verdachte forwarding regels in Exchange Online.

.AUTHOR
Mounir Oss

.DESCRIPTION
Zoekt inboxregels met externe forwarding, die mogelijk wijzen op een beveiligingsrisico.
#>

Connect-ExchangeOnline

$mailboxes = Get-Mailbox -ResultSize Unlimited
$results = foreach ($mb in $mailboxes) {
    $rules = Get-InboxRule -Mailbox $mb.UserPrincipalName
    foreach ($rule in $rules) {
        if ($rule.ForwardTo -or $rule.ForwardAsAttachmentTo -or $rule.RedirectTo) {
            [PSCustomObject]@{
                Mailbox = $mb.UserPrincipalName
                RuleName = $rule.Name
                Action = ($rule | Select-Object ForwardTo, RedirectTo, ForwardAsAttachmentTo)
            }
        }
    }
}

$results | Export-Csv -Path "./ForwardingRules_Report.csv" -NoTypeInformation
Write-Host "Rapport met forwardingregels opgeslagen als ForwardingRules_Report.csv"
