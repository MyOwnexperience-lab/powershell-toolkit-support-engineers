# PowerShell Toolkit for IT Support Engineers

Een verzameling krachtige PowerShell-scripts voor IT-support en systeembeheerders.  
Gemaakt om veelvoorkomende én complexe beheertaken te automatiseren in Microsoft 365, Azure AD en on-premises omgevingen.

## Inhoud
- MFA-analyse script
- Shadow admin detector
- Verdachte doorstuurregels detectie
- En meer...

## Auteur
Mounir Oss
